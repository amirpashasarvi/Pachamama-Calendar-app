# Developer setup — Pachamama Booking Management

> **Received this as a gift?** Start with **[Mangobeds.md](./Mangobeds.md)** — that guide covers your own Firebase project from scratch.

This file is for developers working on the **original** production project (shared access, same Firebase).

## What you get

- Full source code for the React + TypeScript + Firebase app
- Connection to the **production** Firebase project (`pachamama-calendar`) via `firebase-applet-config.json`
- Same bookings, settings, and data as the deployed admin site (not a separate sandbox)

## Before you start (project owner)

The owner **must add your Google email as an admin before your first login**. New sign-ins are blocked unless your email already exists in Firestore.

1. Sign in to the app as an existing admin
2. Open **Settings** → **Users**
3. Click **Add user**
4. Enter:
   - **Email:** your Google account email (exact address you will use to sign in)
   - **Name:** your display name
   - **Role:** **Administrator**
5. Save

Without this step, Google sign-in will succeed in Firebase Auth but the app will show *"Your account is not authorized"*.

## Local setup

**Requirements:** Node.js 22 or newer

```bash
npm install
npm run dev
```

Open **http://localhost:3000** in your browser.

`localhost` is normally already allowed in Firebase Authentication. If sign-in fails with *unauthorized domain*, ask the owner to add `localhost` under Firebase Console → Authentication → Settings → Authorized domains.

## Sign in

1. Click **Sign in with Google**
2. Use the **same Google account email** the owner added in Settings → Users
3. On first login, the app attaches your Firebase UID to your user record automatically

You should land in the calendar with admin access (Settings, Finances, Alerts, Recently Deleted, etc.).

## Useful commands

| Command | Purpose |
|---------|---------|
| `npm run dev` | Local dev server (port 3000) |
| `npm run build` | Production build to `dist/` |
| `npm run lint` | TypeScript check |
| `npm run preview` | Preview production build locally |

## Project structure

| Path | Description |
|------|-------------|
| `src/components/calendar/` | Calendar grid, bookings, header |
| `src/components/modals/` | Booking, settings, finances, etc. |
| `src/hooks/` | Auth, booking data, housekeeping |
| `src/services/firebase.ts` | Firebase init |
| `firestore.rules` | Security rules (must be published in Firebase Console after changes) |
| `firebase-applet-config.json` | Client Firebase config (public; already in the deployed app) |

## Security notes

- **Do not share** files in `scripts/keys/` — those are Firebase Admin service account private keys (not included in this zip).
- **Do not commit** `.env` files or service account JSON keys.
- `firebase-applet-config.json` is safe to keep in the repo; access control is enforced by Firestore rules and pre-approved users.

## Deploying changes

Production is hosted on **Netlify** (`npm run build`, publish `dist/`). Deployment is managed by the project owner via GitHub → Netlify.

If you change `firestore.rules`, the owner must publish them in Firebase Console → Firestore → Rules for the `pachamama-calendar` project.

## Troubleshooting

| Problem | Fix |
|---------|-----|
| "Your account is not authorized" | Owner must add your Google email in Settings → Users with role **Administrator** |
| "Permission denied" on save | Confirm Firestore rules are published; confirm you are signed in as admin |
| Google popup blocked | Allow popups for `localhost:3000` |
| Blank calendar / loading forever | Check browser console; verify network access to Firebase |

## Contact

Ask the project owner for admin user setup, Netlify deploy access, or Firebase Console access if you need to publish rules or manage auth domains.
