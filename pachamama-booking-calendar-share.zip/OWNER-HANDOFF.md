# Gifting this app to a developer friend

## What to send

Send **`pachamama-booking-calendar-share.zip`** from this folder:

```
/Users/pachamama/Downloads/pachamama-booking-calendar (1)/pachamama-booking-calendar-share.zip
```

Tell them to open **`Mangobeds.md`** inside the zip first.

## What they get

- Full source code for the booking calendar app
- Instructions to create **their own** Firebase project (empty database, their admin login)
- Freedom to customize and deploy for their own business

## What they do NOT get (on purpose)

- Access to **your** live Pachamama Firebase data or Netlify site
- Your Firebase admin keys

The gift zip uses `firebase-applet-config.example.json` instead of your production config, so they start fresh.

## Your app keeps working

Nothing changes for you. Your local `firebase-applet-config.json` and live site stay as they are.

## If you ever want to share live access instead

That is a different handoff: add their Google email in **Settings → Users** as Administrator and share the production config. Only do that if you trust them with real booking data. For a code gift, the zip + `Mangobeds.md` path above is the right approach.
